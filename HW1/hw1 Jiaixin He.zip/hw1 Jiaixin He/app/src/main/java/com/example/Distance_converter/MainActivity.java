package com.example.Distance_converter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    //define parameters
    private EditText Input;
    private TextView Output;
    private TextView MIV;
    private TextView KMV;
    private TextView historyValue;
    private RadioButton MIB;
    private RadioButton KMB;
    String HistoryResult;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //log
        Log.v(TAG, "onCreate: program is in onCreate!");

        //bind variables by ID
        Input = findViewById(R.id.InputValue);
        Output = findViewById(R.id.Text);
        MIV= findViewById(R.id.MValueText);
        KMV= findViewById(R.id.KValueText);
        MIB = findViewById(R.id.MIButton);
        KMB = findViewById(R.id.KMButton);
        historyValue = findViewById(R.id.HistoryText);

        //sets scroll movement to 'history' text
        historyValue.setMovementMethod(new ScrollingMovementMethod());

    }



    //different cases when select buttons
    public void radioOnclick(View v) {
        if (KMB.isChecked()) {
            MIV.setText(R.string.KM);
            KMV.setText(R.string.MI);

        } else {
            KMV.setText(R.string.KM);
            MIV.setText(R.string.MI);
        }

        Input.setText("");
        Output.setText("");
    }

    //convert function
    public void convert(View v) {

        //initialize InputNumber

        double ConvertNumber;
        String Result;
        String inputValue = Input.getText().toString();
        if (!(inputValue == "")) {
            double InputNumber = Double.parseDouble(inputValue);
            if (KMB.isChecked()) {
                ConvertNumber = 0.621371 * InputNumber;
                Result = String.format("%,.1f", ConvertNumber);
                Output.setText(Result);
                HistoryResult = historyValue.getText().toString();
                historyValue.setText(InputNumber + " Km " + "==> " + Result + " Mi" + "\n" + HistoryResult);

            } else {
                ConvertNumber = 1.60934 * InputNumber ;
                Result = String.format("%,.1f", ConvertNumber);
                Output.setText(Result);
                HistoryResult = historyValue.getText().toString();
                historyValue.setText(InputNumber + " Mi " + "==> " + Result + " Km" + "\n"+ HistoryResult);
            }
        } else {
            //notify users when the input is empty
            Toast.makeText(this, "Please type in numbers", Toast.LENGTH_SHORT).show();

        }

    }


    //clear history when click the clear button
    public void clear(View v) {
        historyValue.setText("");
        HistoryResult = ("");
    }

    //put info in bundle when rotating
    @Override
    protected void onSaveInstanceState(Bundle outState) {

        outState.putString("HISTORY", historyValue.getText().toString());
        outState.putString("HISTORYRESULT", HistoryResult);
        outState.putString("OUTPUT", Output.getText().toString());
        outState.putString("kmv",KMV.getText().toString());
        outState.putString("miv",MIV.getText().toString());

        //call super last
        super.onSaveInstanceState(outState);

        //log debug
        Log.d(TAG, "onSaveInstanceState: This is in onSaveInstanceState");

    }

    //restore info from bundle when restart
    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        //call super first
        super.onRestoreInstanceState(savedInstanceState);

        //log debug
        Log.d(TAG, "onRestoreInstanceState: This is in onRestoreInstanceState");

        historyValue.setText(savedInstanceState.getString("HISTORY"));
        HistoryResult = savedInstanceState.getString("HISTORYRESULT");
        Output.setText(savedInstanceState.getString("OUTPUT"));
        KMV.setText(savedInstanceState.getString("kmv"));
        MIV.setText(savedInstanceState.getString("miv"));

    }
}
